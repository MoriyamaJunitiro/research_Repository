import subprocess

def main():

    subprocess.call("sed -e '138s/0/-0.1/g' -e '138s/ 1/1.1/g' CONTCAR.vesta > CONTCAR1.vesta", shell=True)
    subprocess.call("sed -e '140a 1  H  Fe  0.0000 2.50000 0 1 1 0 1 0.250 2.000 127 127 127' CONTCAR1.vesta > CONTCAR2.vesta",shell=True)

    subprocess.call("sed -e '141a 1  H  Cr  0.0000 2.50000 0 1 1 0 1 0.250 2.000 127 127 127' CONTCAR2.vesta > CONTCAR3.vesta",shell=True)

    
    subprocess.call("sed -e '214s/0  1  0/2  1  0/g' CONTCAR3.vesta > CONTCAR4.vesta",shell=True)

    subprocess.call("sed -e '220s/1/2/g' CONTCAR4.vesta > CONTCAR5.vesta",shell=True)
    
    subprocess.call("sed -e '177s/255 204 204 204/128 204 204 100/g' CONTCAR5.vesta > CONTCAR6.vesta",shell=True)
    subprocess.call("sed -e '179a 1 0.00000 0.00000 0.800000 0' CONTCAR6.vesta >CONTCAR7.vesta",shell=True)
    subprocess.call("sed -e '180a 0 0 0 0 0' CONTCAR7.vesta >CONTCAR8.vesta",shell=True)
    subprocess.call("sed -e '183a 1 0.250 255 0 0 1' CONTCAR8.vesta >CONTCAR9.vesta",shell=True)
    subprocess.call("sed -e '181a 1 0.00000 0.00000 -0.80000 0' CONTCAR9.vesta >CONTCAR10.vesta",shell=True)
    subprocess.call("sed -e '182a 0 0 0 0 0' CONTCAR10.vesta >CONTCAR11.vesta",shell=True)
    subprocess.call("sed -e '186a 2 0.250 0 128 255' CONTCAR11.vesta >CONTCAR12.vesta",shell=True)

    subprocess.call("mv CONTCAR12.vesta CONTCAR_VEC.vesta",shell=True)
    subprocess.call("rm CONTCAR1.vesta",shell=True)
    subprocess.call("rm CONTCAR2.vesta",shell=True)
    subprocess.call("rm CONTCAR3.vesta",shell=True)
    subprocess.call("rm CONTCAR4.vesta",shell=True)
    subprocess.call("rm CONTCAR5.vesta",shell=True)
    subprocess.call("rm CONTCAR6.vesta",shell=True)
    subprocess.call("rm CONTCAR7.vesta",shell=True)
    subprocess.call("rm CONTCAR8.vesta",shell=True)
    subprocess.call("rm CONTCAR9.vesta",shell=True)
    subprocess.call("rm CONTCAR10.vesta",shell=True)
    subprocess.call("rm CONTCAR11.vesta",shell=True)

if __name__=="__main__":
    main()
